// Script que detecta cuando se aprueba un PR en Azure DevOps
// y abre automáticamente el formulario de revisión cruzada

(function() {
  'use strict';

  let formAlreadyOpened = false;
  let lastPRId = null;

  // URL del formulario de revisión cruzada (parametrizada)
  const FORM_URL = 'https://forms.office.com/pages/responsepage.aspx?id=gtaw9ZcUsE2QGWYANVVOcv0lq25Y2DxMiaN5nTimN0JUOEZaUUdYT0w3WkhXSDZISTRQUVA2NkFXWS4u';

  // Función para obtener el ID del PR actual
  function getCurrentPRId() {
    const urlMatch = window.location.href.match(/pullrequest\/(\d+)/);
    return urlMatch ? urlMatch[1] : null;
  }

  // Función para obtener el nombre de la rama del PR
  function getBranchName() {
    // Buscar el nombre de la rama en la página de Azure DevOps
    // Puede estar en diferentes lugares dependiendo de la versión de Azure DevOps
    const branchSelectors = [
      '.repos-pr-header-branches .source-branch',
      '.repos-pr-header-branches .bolt-link',
      '[data-automation-key="source-branch"]',
      '.vc-pullrequest-view-details-header .source-branch',
      '.vc-pullrequest-view-details-header .bolt-link',
      '.repos-pr-header-branches a',
      '.bolt-header-title .bolt-link',
      'a[href*="branchName"]',
      '.pr-header-branches a'
    ];

    // Intentar con selectores específicos
    for (const selector of branchSelectors) {
      const elements = document.querySelectorAll(selector);
      for (const element of elements) {
        const branchName = element.textContent.trim();
        console.log('🔍 Elemento encontrado:', selector, '-> Valor:', branchName);
        if (branchName && branchName.includes('/') && branchName.includes('feature')) {
          console.log('✅ Rama detectada:', branchName);
          return branchName;
        }
      }
    }

    // Buscar en todos los links de la página que contengan "feature/dev-"
    const allLinks = document.querySelectorAll('a');
    for (const link of allLinks) {
      const text = link.textContent.trim();
      if (text.startsWith('feature/dev-')) {
        console.log('✅ Rama detectada en link:', text);
        return text;
      }
    }

    // Intentar obtener del título de la página
    const titleMatch = document.title.match(/\[(.*)\]/);
    if (titleMatch && titleMatch[1].includes('/')) {
      console.log('✅ Rama detectada en título:', titleMatch[1]);
      return titleMatch[1];
    }

    // Buscar en la URL si tiene el parámetro de la rama
    const urlParams = new URLSearchParams(window.location.search);
    const sourceBranch = urlParams.get('sourceBranch');
    if (sourceBranch) {
      console.log('✅ Rama detectada en URL:', sourceBranch);
      return sourceBranch;
    }

    console.warn('⚠️ No se pudo detectar el nombre de la rama');
    return null;
  }

  // Función para validar si la rama requiere revisión cruzada
  function requiresCrossReview(branchName) {
    if (!branchName) {
      return false;
    }
    return branchName.startsWith('feature/dev-');
  }

  // Función para abrir el formulario
  async function openForm() {
    const currentPRId = getCurrentPRId();
    
    // Evitar abrir múltiples veces para el mismo PR
    if (formAlreadyOpened && lastPRId === currentPRId) {
      return;
    }

    // Validar el nombre de la rama
    const branchName = getBranchName();
    console.log('🔍 Rama detectada:', branchName);
    
    if (!requiresCrossReview(branchName)) {
      console.log('ℹ️ La rama no requiere revisión cruzada');
      showNotification('La rama no requiere revisión cruzada', 'info');
      formAlreadyOpened = true;
      lastPRId = currentPRId;
      return;
    }

    console.log('✅ Abriendo formulario de revisión cruzada...');
    
    // Abrir el formulario en una nueva pestaña
    window.open(FORM_URL, '_blank');
    
    formAlreadyOpened = true;
    lastPRId = currentPRId;
    
    // Mostrar notificación
    showNotification('Formulario de revisión cruzada abierto', 'success');
    
    // Resetear después de 5 minutos (por si se aprueba otro PR)
    setTimeout(() => {
      formAlreadyOpened = false;
    }, 5 * 60 * 1000);
  }

  // Función para mostrar notificación en la página
  function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 12px 18px;
      background-color: rgba(255, 209, 0, 0.95);
      color: #0f265c;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      border: 1px solid rgba(15, 38, 92, 0.3);
      backdrop-filter: blur(10px);
      z-index: 10000;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      font-size: 13px;
      font-weight: 500;
      animation: slideIn 0.3s ease-out;
      max-width: 300px;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.style.animation = 'slideOut 0.3s ease-out';
      setTimeout(() => notification.remove(), 300);
    }, 4000);
  }

  // Agregar estilos para las animaciones
  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideIn {
      from {
        transform: translateX(400px);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }
    @keyframes slideOut {
      from {
        transform: translateX(0);
        opacity: 1;
      }
      to {
        transform: translateX(400px);
        opacity: 0;
      }
    }
  `;
  document.head.appendChild(style);

  // Observar cambios en el DOM para detectar cuando se hace clic en "Approve"
  function observeApprovalButton() {
    // Buscar el botón de aprobación
    const observer = new MutationObserver(async (mutations) => {
      // Verificar si el usuario ya aprobó el PR
      const approvedIndicator = document.querySelector('[aria-label*="approved"], [title*="approved"], .vote-approved');
      const approveButton = document.querySelector('button[aria-label*="Approve"], button[title*="Approve"]');
      
      if (approvedIndicator || (approveButton && approveButton.getAttribute('aria-pressed') === 'true')) {
        const currentPRId = getCurrentPRId();
        if (!formAlreadyOpened || lastPRId !== currentPRId) {
          console.log('🎯 Aprobación detectada en PR #' + currentPRId);
          await openForm();
        }
      }
    });

    // Observar cambios en el área de votación
    const targetNode = document.body;
    observer.observe(targetNode, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['aria-pressed', 'class', 'aria-label']
    });

    // También agregar listener directo a los botones de aprobación
    document.addEventListener('click', async (event) => {
      const target = event.target.closest('button');
      if (target && (
        target.getAttribute('aria-label')?.toLowerCase().includes('approve') ||
        target.textContent?.toLowerCase().includes('approve') ||
        target.title?.toLowerCase().includes('approve')
      )) {
        // Esperar un momento para que Azure DevOps procese la aprobación
        setTimeout(async () => {
          await openForm();
        }, 1000);
      }
    }, true);
  }

  // Iniciar la observación cuando la página esté lista
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', observeApprovalButton);
  } else {
    observeApprovalButton();
  }

  console.log('🚀 Extensión de Formulario de Revisión Cruzada cargada');
})();
