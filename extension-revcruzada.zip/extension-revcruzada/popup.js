// Script para el popup informativo

document.addEventListener('DOMContentLoaded', () => {
  console.log('✅ Extensión de Revisión Cruzada activa');
  console.log('📋 Formulario configurado para ramas que comienzan con: feature/dev-');
});
