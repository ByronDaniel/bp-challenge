# 📋 Extensión: Formulario de Revisión Cruzada para Azure DevOps

## 📖 Descripción

Dado que a veces se nos pasa llenar el formulario de revisión cruzada, esta extensión ayuda a recordar al desarrollador abriendo automáticamente el formulario cuando se aprueba un Pull Request en Azure DevOps.

La extensión **solo abre el formulario** para ramas que comienzan con `feature/dev-`, asegurando que únicamente los PRs que requieren revisión cruzada activen el recordatorio.

## 🎯 Características

- ✅ **Detección automática**: Detecta cuando apruebas un PR en Azure DevOps
- 🔍 **Validación de rama**: Solo abre el formulario para ramas `feature/dev-*`
- 🚀 **Apertura automática**: Abre el formulario en una nueva pestaña
- 🔔 **Notificaciones minimalistas**: Alertas visuales con diseño moderno y transparencia
- 🎨 **Diseño corporativo**: Colores personalizados (#ffd100 y #0f265c)
- 🛡️ **Prevención de duplicados**: No abre múltiples veces el mismo formulario
- ⚡ **Sin configuración**: URL del formulario preconfigurada

## 📦 Instalación

### Opción 1: Descargar el ZIP

1. **Descarga** el archivo ZIP de la extensión
2. **Extrae** el contenido en una carpeta de tu preferencia

### Opción 2: Clonar el repositorio

```bash
git clone <url-del-repositorio>
cd browser-extension
```

### Importar la Extensión en el Navegador

#### Chrome
1. Abre Chrome y ve a `chrome://extensions/`
2. Activa el **"Modo de desarrollador"** (esquina superior derecha)
3. Haz clic en **"Cargar extensión sin empaquetar"**
4. Selecciona la carpeta `browser-extension/`
5. ✅ ¡Listo! La extensión está instalada

#### Edge
1. Abre Edge y ve a `edge://extensions/`
2. Activa el **"Modo de desarrollador"** (esquina inferior izquierda)
3. Haz clic en **"Cargar extensión descomprimida"**
4. Selecciona la carpeta `browser-extension/`
5. ✅ ¡Listo! La extensión está instalada

## 🚀 Uso

1. **Navega** a cualquier Pull Request en Azure DevOps
2. **Aprueba** el PR haciendo clic en el botón **"Approve"**
3. La extensión **validará** automáticamente el nombre de la rama:
   - ✅ Si la rama comienza con `feature/dev-` → Abre el formulario
   - ℹ️ Si la rama NO comienza con `feature/dev-` → Muestra notificación informativa
4. **Completa** el formulario de revisión cruzada en la nueva pestaña

### Ejemplos de Ramas

**✅ Ramas que ABREN el formulario:**
- `feature/dev-BTPMCDP-1192-hash-account-by-channel`
- `feature/dev-PROYECTO-5678-nueva-funcionalidad`
- `feature/dev-ABC-123-fix-bug`

**❌ Ramas que NO abren el formulario:**
- `hotfix/fix-critical-bug`
- `main`
- `develop`
- `feature/PROYECTO-1234` (sin el prefijo `dev-`)

## 🔧 Cómo Funciona

La extensión utiliza tecnologías web modernas para detectar y responder a las aprobaciones de PRs:

1. **Content Script** (`content.js`): Se inyecta automáticamente en las páginas de PR de Azure DevOps
2. **Detección de rama**: Busca el nombre de la rama en múltiples ubicaciones del DOM
3. **Validación**: Verifica si la rama comienza con `feature/dev-`
4. **MutationObserver**: Detecta cambios en el DOM cuando apruebas un PR
5. **Event Listeners**: Escucha clics en el botón de aprobación
6. **Apertura automática**: Abre el formulario en una nueva pestaña si cumple las condiciones

### Flujo de Trabajo

```
Usuario aprueba PR → Extensión detecta aprobación → Obtiene nombre de rama
                                                              ↓
                                                    ¿Comienza con feature/dev-?
                                                              ↓
                                    SÍ ✅                                    NO ❌
                                     ↓                                        ↓
                        Abre formulario en nueva pestaña        Muestra notificación informativa
                        Muestra notificación de éxito           "La rama no requiere revisión cruzada"
```

## 🛠️ Solución de Problemas

### El formulario no se abre automáticamente

**Posibles causas:**
1. La rama no comienza con `feature/dev-`
2. La extensión no está habilitada
3. El PR ya fue aprobado anteriormente (prevención de duplicados)

**Soluciones:**
- Verifica el nombre de la rama en Azure DevOps
- Asegúrate de que la extensión esté habilitada en `chrome://extensions/`
- Recarga la página del PR (F5)
- Abre la consola del navegador (F12) y busca logs con 🔍 y ✅

### La notificación no aparece

1. Verifica que la extensión tenga permisos para ejecutarse en Azure DevOps
2. Recarga la extensión desde `chrome://extensions/`
3. Limpia la caché del navegador

### La extensión no detecta la rama correctamente

1. Abre la consola del navegador (F12)
2. Busca el log `🔍 Rama detectada:` para ver qué rama está detectando
3. Si no aparece ninguna rama, reporta el problema con una captura de pantalla

## 📝 Notas Importantes

- ⚠️ La extensión **solo funciona** en páginas de Pull Request de Azure DevOps
- 🔐 Requiere permisos para acceder a `dev.azure.com` y `*.visualstudio.com`
- 🛡️ El formulario se abre **solo una vez por PR** para evitar duplicados
- ⏱️ Después de **5 minutos**, se resetea el estado por si apruebas otro PR
- 🎯 La URL del formulario está **preconfigurada** en el código

## 🔒 Privacidad y Seguridad

- ✅ La extensión **NO recopila** ningún dato personal
- ✅ **NO envía** información a servidores externos
- ✅ Solo se ejecuta en páginas de Azure DevOps
- ✅ Todo el procesamiento es **local** en tu navegador
- ✅ Código abierto y auditable

## 📄 Estructura del Proyecto

```
browser-extension/
├── manifest.json       # Configuración de la extensión (Manifest V3)
├── content.js         # Script principal que detecta aprobaciones y valida ramas
├── popup.html         # Interfaz informativa de la extensión
├── popup.js           # Script del popup
├── create-icons.html  # Generador de iconos (opcional)
├── icon16.png         # Icono 16x16
├── icon48.png         # Icono 48x48
├── icon128.png        # Icono 128x128
└── README.md          # Documentación
```

## 🎨 Personalización

Si necesitas personalizar la extensión, puedes editar:

### Cambiar la URL del formulario
Edita `content.js` línea 11:
```javascript
const FORM_URL = 'https://forms.office.com/pages/responsepage.aspx?id=...';
```

### Modificar el patrón de validación de ramas
Edita `content.js` en la función `requiresCrossReview()`:
```javascript
function requiresCrossReview(branchName) {
  if (!branchName) {
    return false;
  }
  return branchName.startsWith('feature/dev-'); // Cambia este patrón
}
```

### Personalizar colores
- **Popup**: Edita los estilos CSS en `popup.html`
- **Notificaciones**: Edita la función `showNotification()` en `content.js`

### Ajustar tiempos
- **Duración de notificación**: Línea 162 de `content.js` (actualmente 4000ms = 4 segundos)
- **Tiempo de reseteo**: Línea 118 de `content.js` (actualmente 5 minutos)

## 📋 Checklist de Instalación

- [ ] Descargar o clonar el repositorio
- [ ] Abrir `chrome://extensions/` o `edge://extensions/`
- [ ] Activar el "Modo de desarrollador"
- [ ] Cargar la extensión sin empaquetar
- [ ] Verificar que los iconos se muestren correctamente
- [ ] Probar aprobando un PR con rama `feature/dev-*`
- [ ] Verificar que el formulario se abra automáticamente

## 🤝 Contribuciones

Si deseas mejorar esta extensión:

1. Haz un fork del repositorio
2. Crea una rama para tu feature (`git checkout -b feature/nueva-funcionalidad`)
3. Commit tus cambios (`git commit -m 'Agrega nueva funcionalidad'`)
4. Push a la rama (`git push origin feature/nueva-funcionalidad`)
5. Abre un Pull Request

## 📞 Soporte

Si encuentras algún problema o tienes sugerencias:

1. **Revisa los logs**: Abre la consola del navegador (F12) en la página del PR
2. **Verifica la configuración**: Asegúrate de que la extensión esté habilitada
3. **Reporta el problema**: Incluye capturas de pantalla y logs de la consola

---

**Versión**: 1.0.0  
**Autor**: Equipo de Desarrollo  
**Compatible con**: Chrome, Edge, Brave y otros navegadores basados en Chromium  
**Requiere**: Manifest V3  
**Licencia**: MIT
